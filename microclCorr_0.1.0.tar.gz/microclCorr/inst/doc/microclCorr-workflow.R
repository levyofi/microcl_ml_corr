## ----include = FALSE----------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>",
  fig.path = "man/figures/vignette-",
  out.width = "100%"
)

## ----reproducible-example-----------------------------------------------------
library(microclCorr)

# ── 1. Load Bundled Empirical Data ───────────────────────────────────────────
data(microclimate_sample)

# Prepare dataset (parses datetime, validates columns, one-hot encodes microhabitat)
prepared <- prepare_dataframe(microclimate_sample)

# Define predictor feature columns
features <- c("TAREF", "RH", "VREF", "SOLR", "TSKYC", "DEW",
              "Hour_sin", "Hour_cos",
              "microhabitat_air", "microhabitat_shade", "microhabitat_sun")

# ── 2. Blocked Temporal Split ────────────────────────────────────────────────
# 70% training, 15% validation, 15% testing in 2-day contiguous blocks
splits <- split_train_val_test(
  prepared,
  train_pct  = 0.70,
  val_pct    = 0.15,
  block_days = 2,
  seed       = 42
)

# ── 3. Train Random Forest Model ─────────────────────────────────────────────
rf_model <- train_rf(
  train_X   = splits$train[, features],
  train_y   = splits$train$residual,
  num_trees = 100,
  tune      = FALSE,
  seed      = 42
)

# ── 4. Evaluate Correction Performance on Test Set ───────────────────────────
eval_results <- evaluate_correction(
  model           = rf_model,
  X               = splits$test[, features],
  y               = splits$test$residual,
  base_prediction = splits$test$predicted,
  model_type      = "rf"
)

cat(sprintf("Baseline Uncorrected RMSE : %.2f deg C (R^2 = %.3f)\n",
            eval_results$rmse_base, eval_results$r2_base))
cat(sprintf("ML-Corrected RMSE         : %.2f deg C (R^2 = %.3f)\n",
            eval_results$rmse_corr, eval_results$r2_corr))
cat(sprintf("RMSE Error Reduction      : %.1f%%\n",
            100 * (1 - eval_results$rmse_corr / eval_results$rmse_base)))

# ── 5. Save and Reload Model Bundle ──────────────────────────────────────────
tmp_model_file <- tempfile(fileext = ".rds")
save_correction_model(
  model        = rf_model,
  feature_cols = features,
  path         = tmp_model_file
)

# Load the saved model bundle
bundle <- load_correction_model(tmp_model_file)
unlink(tmp_model_file)

# ── 6. Predicting on New Unmeasured Data ─────────────────────────────────────
# Simulate a new dataset of physical model predictions where no field loggers exist.
# Notice that ground-truth measurements (residual, logger columns) are omitted:
new_physical_data <- splits$test
new_physical_data$residual   <- NULL  # Residuals are unknown in real deployment!
new_physical_data$sun_temp   <- NULL
new_physical_data$shade_temp <- NULL
new_physical_data$air_temp   <- NULL

# Apply the correction model to the new physical predictions
corrected_predictions <- correct_predictions(
  model        = bundle$model,
  new_data     = new_physical_data,
  model_type   = bundle$model_type,
  feature_cols = bundle$feature_cols
)

# Inspect the corrected output
head(corrected_predictions)

## ----lstm-pipeline, eval = FALSE----------------------------------------------
# # 0. Configure Python and TensorFlow environment
# setup_tensorflow()
# 
# # 1. Feature normalization (min-max scaling fit on training set)
# scaled <- lstm_scaling(splits$train, splits$val, splits$test)
# 
# # 2. Reshape into sliding sequence windows (e.g. 4-hour temporal lookback)
# lstm_data <- lstm_specific_preprocessing(
#   train        = scaled$train,
#   val          = scaled$val,
#   test         = scaled$test,
#   window_size  = 4,
#   ts_names_col = "time_series_doc"
# )
# 
# # 3. Train LSTM model (or use lstm_hypertuning for automated tuning)
# lstm_model <- train_lstm(
#   train_X    = lstm_data$train_dict$X,
#   train_y    = lstm_data$train_dict$y,
#   val_X      = lstm_data$val_dict$X,
#   val_y      = lstm_data$val_dict$y,
#   n_units    = 64,
#   n_layers   = 2,
#   dropout    = 0.1,
#   lr         = 0.001,
#   epochs     = 50,
#   batch_size = 32,
#   seed       = 42
# )
# 
# # 4. Save LSTM bundle (includes scaler parameters)
# save_correction_model(
#   model        = lstm_model,
#   scaler       = scaled$scaler,
#   feature_cols = features,
#   path         = "best_lstm_model.rds"
# )
# 
# # 5. Predict on new unmeasured data using the saved scaler
# loaded_lstm <- load_correction_model("best_lstm_model.rds")
# 
# corrected_lstm <- correct_predictions(
#   model        = loaded_lstm$model,
#   new_data     = new_physical_data,
#   model_type   = "lstm",
#   feature_cols = loaded_lstm$feature_cols,
#   scaler       = loaded_lstm$scaler,
#   window_size  = 4,
#   datetime_col = "time"
# )
# 
# head(corrected_lstm)

