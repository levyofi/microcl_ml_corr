# inst/examples/examples_utility_functions.R
# Shared utility functions and model persistence helpers for microclCorr examples.
# Source this file to access helper functions used across scenario scripts.

# ---- Model Persistence & Environment Setup ----
# These general functions are exported by the microclCorr package.
save_correction_model <- microclCorr::save_correction_model
load_correction_model <- microclCorr::load_correction_model
setup_tensorflow      <- microclCorr::setup_tensorflow
check_lstm_environment <- microclCorr::check_lstm_environment

# ---- Data Splitting & Learning Curves ----

# load_splits_from_csv -----------------------------------------------------------
# Scenarios 4-8 use a pre-defined CSV file that assigns every row in the dataset
# to one of three roles: "train" (used to fit the model), "val" (used to tune
# settings during training), or "test" (held out to measure final accuracy).
# This function attaches those assignments to the data by matching on timestamp
# and logger ID, then splits the data into three separate tables.
load_splits_from_csv <- function(data, splits_csv, site_col, datetime_col = "time") {
  sp  <- read.csv(splits_csv, stringsAsFactors = FALSE)

  # Standardise timestamp format so rows can be matched across the two files
  fmt <- function(x) format(as.POSIXct(x, tz = "UTC"), "%Y-%m-%d %H:%M:%S", tz = "UTC")
  data$.t <- fmt(data[[datetime_col]])
  sp$.t   <- fmt(sp[[datetime_col]])

  # Join split labels onto the data rows
  m <- merge(data, sp[, c(".t", site_col, "split")], by = c(".t", site_col), all.x = TRUE)
  m <- m[order(m[[datetime_col]]), ]
  m$.t <- NULL
  cols <- setdiff(names(m), "split")   # keep all columns except the temporary "split" label

  list(
    train = m[!is.na(m$split) & m$split == "train", cols],
    val   = m[!is.na(m$split) & m$split == "val",   cols],
    test  = m[!is.na(m$split) & m$split == "test",  cols]
  )
}

# find_min_training_days ---------------------------------------------------------
# Answers the question: "How many days of logger data do I actually need?"
#
# The function trains RF and/or LSTM at progressively smaller training sizes
# (e.g. 1, 2, 3, 7, 14, 21, 28, 35, 42 days) and finds the minimum number of
# days where accuracy stays within `tolerance` of the full-data result.
find_min_training_days <- function(splits, lstm_2h, feature_cols,
                                   rf_model, lstm_model, lstm_params,
                                   rf_test, X_test_lstm, y_test_lstm, base_test_lstm,
                                   site_col,
                                   tolerance     = 0.10,
                                   training_days = c(1, 2, 3, 7, 14, 21, 28, 35, 42),
                                   n_runs        = 5,
                                   seed          = 123) {
  library(ggplot2)

  # Reference RMSE: performance with all available training data
  ref_rf   <- evaluate_correction(rf_model, rf_test[, feature_cols],
                                   rf_test$residual, rf_test$predicted,
                                   model_type = "rf")$rmse_corr
  ref_lstm <- evaluate_correction(lstm_model, X_test_lstm, y_test_lstm,
                                   base_test_lstm, model_type = "lstm")$rmse_corr

  # Training rows sorted by time (first N days = first N*24 rows)
  train_sorted <- splits$train[order(splits$train$time), ]

  results <- list()

  for (n_days in training_days) {
    n_hours    <- n_days * 24
    rf_partial <- train_sorted[seq_len(min(nrow(train_sorted), n_hours)), ]
    lstm_n     <- min(length(lstm_2h$train_dict$y), n_hours)
    X_partial  <- lstm_2h$train_dict$X[seq_len(lstm_n), , , drop = FALSE]
    y_partial  <- lstm_2h$train_dict$y[seq_len(lstm_n)]

    for (run in seq_len(n_runs) - 1L) {
      # RF: train with different seed each run
      rf_m <- train_rf(rf_partial[, feature_cols], rf_partial$residual,
                        tune = FALSE, seed = run)
      m_rf <- evaluate_correction(rf_m, rf_test[, feature_cols],
                                   rf_test$residual, rf_test$predicted,
                                   model_type = "rf")
      results[[length(results) + 1]] <- data.frame(
        model = "RF", n_days = n_days, run = run,
        rmse_corr = m_rf$rmse_corr, rmse_base = m_rf$rmse_base)

      # LSTM: train with tuned architecture, different seed each run
      lstm_m <- train_lstm(X_partial, y_partial,
                            lstm_2h$val_dict$X, lstm_2h$val_dict$y,
                            n_units    = lstm_params$n_units,
                            n_layers   = lstm_params$n_layers,
                            dropout    = lstm_params$dropout,
                            lr         = lstm_params$lr,
                            epochs = 40, batch_size = 32, patience = 10,
                            seed   = run)
      m_lstm <- evaluate_correction(lstm_m, X_test_lstm, y_test_lstm,
                                     base_test_lstm, model_type = "lstm")
      results[[length(results) + 1]] <- data.frame(
        model = "LSTM_2h", n_days = n_days, run = run,
        rmse_corr = m_lstm$rmse_corr, rmse_base = m_lstm$rmse_base)
    }
  }

  results_df <- do.call(rbind, results)

  # Summary: mean ± SD per model per training size
  summ    <- aggregate(cbind(rmse_corr, rmse_base) ~ model + n_days, results_df, mean)
  summ_sd <- aggregate(rmse_corr ~ model + n_days, results_df, sd)
  summ$sd_corr <- summ_sd$rmse_corr

  # Minimum days within tolerance of full-data RMSE
  thresholds <- c(RF = ref_rf * (1 + tolerance), LSTM_2h = ref_lstm * (1 + tolerance))
  min_days <- sapply(c("RF", "LSTM_2h"), function(m) {
    sub <- summ[summ$model == m, ]
    passing <- sub$n_days[sub$rmse_corr <= thresholds[m]]
    if (length(passing) == 0) max(training_days) else min(passing)
  })
  names(min_days) <- c("RF", "LSTM_2h")

  # Learning curve plot
  ref_lines <- data.frame(
    model     = c("RF", "LSTM_2h"),
    threshold = c(thresholds["RF"], thresholds["LSTM_2h"])
  )
  p <- ggplot(summ, aes(x = n_days, y = rmse_corr, color = model, fill = model)) +
    geom_ribbon(aes(ymin = rmse_corr - sd_corr, ymax = rmse_corr + sd_corr),
                alpha = 0.15, color = NA) +
    geom_line(linewidth = 1.0) +
    geom_point(size = 1.5) +
    geom_hline(aes(yintercept = threshold, color = model),
               data = ref_lines, linetype = "dashed", linewidth = 0.7, show.legend = FALSE) +
    scale_color_manual(values = c("RF" = "#10b981", "LSTM_2h" = "#3b82f6"),
                       labels = c("RF" = "Random Forest", "LSTM_2h" = "LSTM (2h)")) +
    scale_fill_manual(values  = c("RF" = "#10b981", "LSTM_2h" = "#3b82f6"),
                      labels  = c("RF" = "Random Forest", "LSTM_2h" = "LSTM (2h)")) +
    scale_x_continuous(breaks = training_days) +
    labs(title    = sprintf("Minimum Training Data Search  (tolerance = %.0f%%)", tolerance * 100),
         subtitle = sprintf("RF: %d days | LSTM: %d days to reach within %.0f%% of full-data RMSE",
                            min_days["RF"], min_days["LSTM_2h"], tolerance * 100),
         x     = "Training Data Size (Days)",
         y     = "Test RMSE (°C)  — lower is better",
         color = "Model", fill = "Model") +
    theme_minimal(base_size = 11) +
    theme(plot.title    = element_text(face = "bold", hjust = 0.5),
          plot.subtitle = element_text(hjust = 0.5, color = "#555555"),
          legend.position = "bottom", panel.grid.minor = element_blank())

  list(results = results_df, summary = summ, min_days = min_days, plot = p)
}

# results_row --------------------------------------------------------------------
# Convenience function that turns the output of evaluate_correction() into a
# single-row data frame, also computing the percentage improvement over the
# uncorrected NicheMapR baseline.
results_row <- function(model_name, site, metrics) {
  data.frame(
    model           = model_name,
    site            = site,
    rmse_base       = metrics$rmse_base,   # NicheMapR error before correction
    rmse_corr       = metrics$rmse_corr,   # model error after correction
    improvement_pct = (metrics$rmse_base - metrics$rmse_corr) / metrics$rmse_base * 100,
    stringsAsFactors = FALSE
  )
}

# logger_temp_stats --------------------------------------------------------------
# Summarise measured temperatures for one logger's data subset as daily
# aggregates: average daily mean, average daily min, average daily max,
# each reported as mean ± SD across days.
# Returns a single-row data frame labelled by `label`.
logger_temp_stats <- function(data_subset, label) {
  meas <- data_subset$predicted + data_subset$residual
  date <- as.Date(data_subset$time)

  daily_mean <- tapply(meas, date, mean, na.rm = TRUE)
  daily_min  <- tapply(meas, date, min,  na.rm = TRUE)
  daily_max  <- tapply(meas, date, max,  na.rm = TRUE)

  data.frame(
    logger         = label,
    daily_mean_avg = round(mean(daily_mean), 2),
    daily_mean_sd  = round(sd(daily_mean),   2),
    daily_min_avg  = round(mean(daily_min),  2),
    daily_min_sd   = round(sd(daily_min),    2),
    daily_max_avg  = round(mean(daily_max),  2),
    daily_max_sd   = round(sd(daily_max),    2)
  )
}

# ---- Plotting & Reporting Helpers ----

# make_residual_hist -------------------------------------------------------------
# Overlay histograms of hourly residuals (measured − predicted) for NicheMapR
# (before correction), RF, and LSTM (after correction).
make_residual_hist <- function(full_df, title_str, has_lstm = TRUE,
                               xlim = NULL, show_strip = TRUE, show_legend = TRUE,
                               panel_letter = NULL, panel_letters = NULL,
                               axis_title_size = 18, axis_text_size = 15, strip_text_size = 11) {
  required <- c("measured", "base", "rf")
  missing  <- setdiff(required, names(full_df))
  if (length(missing) > 0)
    stop("make_residual_hist: full_df missing columns: ",
         paste(missing, collapse = ", "))
  if (has_lstm && !"lstm" %in% names(full_df))
    stop("make_residual_hist: has_lstm=TRUE but 'lstm' column not found in full_df")

  check_nas <- c("measured", "base", "rf")
  if (has_lstm) check_nas <- c(check_nas, "lstm")
  for (col in check_nas) {
    n_na <- sum(is.na(full_df[[col]]))
    if (n_na > 0)
      warning(sprintf("make_residual_hist: %d NA(s) in column '%s' — dropping",
                      n_na, col))
  }
  full_df <- full_df[complete.cases(full_df[, check_nas]), ]

  res_base <- full_df$measured - full_df$base
  res_rf   <- full_df$measured - full_df$rf

  rows <- list(
    data.frame(residual = res_base, model = "Uncorrected\nNicheMapR"),
    data.frame(residual = res_rf,   model = "Random Forest\nCorrection")
  )

  if (has_lstm && "lstm" %in% names(full_df)) {
    rows[[3]] <- data.frame(residual = full_df$measured - full_df$lstm,
                            model    = "LSTM\nCorrection")
  }

  df_long <- do.call(rbind, rows)
  model_levels <- c("Uncorrected\nNicheMapR", "Random Forest\nCorrection", "LSTM\nCorrection")
  clean_labels <- c("Uncorrected NicheMapR", "Random Forest Correction", "LSTM Correction")
  if (!has_lstm) {
    model_levels <- c("Uncorrected\nNicheMapR", "Random Forest\nCorrection")
    clean_labels <- c("Uncorrected NicheMapR", "Random Forest Correction")
  }
  df_long$model <- factor(df_long$model, levels = model_levels)

  cols <- c("Uncorrected\nNicheMapR"   = "#dc2626",
            "Random Forest\nCorrection" = "#059669",
            "LSTM\nCorrection"         = "#2563eb")

  if (is.null(xlim)) xlim <- range(df_long$residual, na.rm = TRUE)

  p <- ggplot2::ggplot(df_long, ggplot2::aes(x = residual, fill = model)) +
    ggplot2::geom_histogram(bins = 50, position = "identity", colour = "white", alpha = 0.8) +
    ggplot2::geom_vline(xintercept = 0, linetype = "dashed",
                        linewidth = 0.7, colour = "#333333") +
    ggplot2::facet_wrap(~ model, ncol = 1, scales = "fixed", strip.position = "right") +
    ggplot2::coord_cartesian(xlim = xlim) +
    ggplot2::scale_fill_manual(values = cols,
                               breaks = model_levels,
                               labels = clean_labels) +
    ggplot2::labs(
      title = title_str,
      x     = expression("Prediction errors (" * degree * "C)"),
      y     = "Count",
      fill  = NULL) +
    ggplot2::theme_minimal(base_size = 14) +
    ggplot2::theme(
      plot.title       = ggplot2::element_text(face = "bold", hjust = 0.5, size = 20),
      axis.title       = ggplot2::element_text(face = "bold", size = axis_title_size),
      axis.text        = ggplot2::element_text(size = axis_text_size),
      legend.position  = "none",
      strip.text.y     = if (show_strip) ggplot2::element_text(face = "bold", size = strip_text_size, angle = 270) else ggplot2::element_blank(),
      strip.background = ggplot2::element_blank(),
      panel.grid.major = ggplot2::element_blank(),
      panel.grid.minor = ggplot2::element_blank(),
      panel.border     = ggplot2::element_rect(colour = "black", fill = NA, linewidth = 0.8))

  if (!is.null(panel_letters)) {
    models_present <- levels(df_long$model)
    ann_df <- data.frame(
      model = factor(models_present, levels = model_levels),
      label = panel_letters[1:length(models_present)],
      x = -Inf,
      y = Inf
    )
    p <- p + ggplot2::geom_text(data = ann_df, ggplot2::aes(x = x, y = y, label = label),
                                 hjust = -0.3, vjust = 1.3, fontface = "bold", size = 6,
                                 inherit.aes = FALSE)
  } else if (!is.null(panel_letter)) {
    p <- p + ggplot2::annotate("text", x = -Inf, y = Inf, label = panel_letter,
                                hjust = -0.3, vjust = 1.3, fontface = "bold", size = 6)
  }

  return(p)
}

# make_pred_plot -----------------------------------------------------------------
# Build a ggplot showing observed, NicheMapR, RF-corrected, and LSTM-corrected
# temperature lines for a single panel.
make_pred_plot <- function(df, title_str, show_legend = TRUE, linewidth_obs = 1.1,
                           has_lstm = TRUE, panel_letter = NULL) {
  p <- ggplot2::ggplot(df, ggplot2::aes(x = time)) +
    ggplot2::geom_line(ggplot2::aes(y = measured, color = "Observed"),
                       linetype = "dotted", linewidth = linewidth_obs) +
    ggplot2::geom_line(ggplot2::aes(y = base,     color = "NicheMapR"),
                       linetype = "dashed", linewidth = 1.0)
  if (has_lstm && "lstm" %in% names(df))
    p <- p + ggplot2::geom_line(ggplot2::aes(y = lstm, color = "LSTM Correction"),
                                 linetype = "solid", linewidth = 1.2)
  p <- p +
    ggplot2::geom_line(ggplot2::aes(y = rf,       color = "Random Forest Correction"),
                       linetype = "solid", linewidth = 1.2) +
    ggplot2::scale_color_manual(
      values = c("Observed"                 = "#111111",
                 "NicheMapR"                = "#dc2626",
                 "Random Forest Correction" = "#059669",
                 "LSTM Correction"          = "#2563eb"),
      breaks = c("Observed", "NicheMapR", "Random Forest Correction", "LSTM Correction")) +
    ggplot2::labs(title = title_str, x = NULL, y = expression("Temperature (" * degree * "C)"), color = NULL) +
    ggplot2::theme_minimal(base_size = 16) +
    ggplot2::theme(
      plot.title       = ggplot2::element_text(face = "bold", hjust = 0.5, size = 18),
      legend.position  = "top",
      legend.text      = ggplot2::element_text(size = 14),
      axis.title       = ggplot2::element_text(size = 16),
      axis.text        = ggplot2::element_text(size = 14),
      panel.grid.major = ggplot2::element_blank(),
      panel.grid.minor = ggplot2::element_blank(),
      panel.border     = ggplot2::element_rect(colour = "black", fill = NA, linewidth = 0.8))

  if (!is.null(panel_letter)) {
    p <- p + ggplot2::annotate("text", x = -Inf, y = Inf, label = panel_letter,
                                hjust = -0.3, vjust = 1.3, fontface = "bold", size = 6)
  }
  return(p)
}

# build_pred_df ------------------------------------------------------------------
# Assemble the four-column prediction data frame from model objects and test data.
# Returns a data frame sorted by time with columns: time, measured, base, rf, lstm.
build_pred_df <- function(rf_test, feature_cols, rf_model,
                           base_test_lstm, lstm_model, X_test_lstm) {
  rf_preds   <- rf_test$predicted +
                ranger:::predict.ranger(rf_model, data = as.data.frame(rf_test[, feature_cols]))$predictions
  lstm_preds <- base_test_lstm +
                as.numeric(predict(lstm_model, X_test_lstm, verbose = 0)[, 1])
  # Preserve the original row order — predictions are positionally aligned to
  # rf_test rows.
  data.frame(
    time     = rf_test$time,
    measured = rf_test$predicted + rf_test$residual,
    base     = rf_test$predicted,
    rf       = rf_preds,
    lstm     = lstm_preds
  )
}

# compute_daily_stats ------------------------------------------------------------
# From a prediction data frame (columns: time, measured, base, rf, and
# optionally lstm), compute summary statistics of daily errors.
compute_daily_stats <- function(full_df) {
  full_df$date <- as.Date(full_df$time)
  daily <- do.call(rbind, lapply(split(full_df, full_df$date), function(d) {
    row <- data.frame(
      date      = d$date[1],
      meas_min  = min(d$measured),  meas_mean = mean(d$measured), meas_max = max(d$measured),
      base_min  = min(d$base),      base_mean = mean(d$base),     base_max = max(d$base),
      rf_min    = min(d$rf),        rf_mean   = mean(d$rf),       rf_max   = max(d$rf)
    )
    if ("lstm" %in% names(d)) {
      row$lstm_min  <- min(d$lstm)
      row$lstm_mean <- mean(d$lstm)
      row$lstm_max  <- max(d$lstm)
    }
    row
  }))

  has_lstm <- all(c("lstm_min", "lstm_mean", "lstm_max") %in% names(daily))
  models   <- if (has_lstm) c("base", "rf", "lstm") else c("base", "rf")

  rows <- lapply(models, function(m) {
    err_mean <- daily[[paste0(m, "_mean")]] - daily$meas_mean
    err_min  <- daily[[paste0(m, "_min")]]  - daily$meas_min
    err_max  <- daily[[paste0(m, "_max")]]  - daily$meas_max
    data.frame(
      model         = m,
      rmse_mean_avg = round(sqrt(mean(err_mean^2)), 2),
      rmse_mean_sd  = round(sd(abs(err_mean)),       2),
      rmse_min_avg  = round(sqrt(mean(err_min^2)),   2),
      rmse_min_sd   = round(sd(abs(err_min)),         2),
      rmse_max_avg  = round(sqrt(mean(err_max^2)),   2),
      rmse_max_sd   = round(sd(abs(err_max)),         2),
      me_mean_avg   = round(mean(err_mean),           2),
      me_mean_sd    = round(sd(err_mean),             2),
      me_min_avg    = round(mean(err_min),            2),
      me_min_sd     = round(sd(err_min),              2),
      me_max_avg    = round(mean(err_max),            2),
      me_max_sd     = round(sd(err_max),              2)
    )
  })
  do.call(rbind, rows)
}

# print_daily_stats --------------------------------------------------------------
# Pretty-print the output of compute_daily_stats() for one microhabitat/logger.
print_daily_stats <- function(ds, label) {
  cat(sprintf("\n  %s\n", label))
  cat(sprintf("  %-8s | %20s | %20s | %20s\n",
              "Model", "Daily Mean RMSE", "Daily Min RMSE", "Daily Max RMSE"))
  for (i in seq_len(nrow(ds))) {
    r <- ds[i, ]
    cat(sprintf("  %-8s | %8.2f ± %-8.2f | %8.2f ± %-8.2f | %8.2f ± %-8.2f\n",
                r$model,
                r$rmse_mean_avg, r$rmse_mean_sd,
                r$rmse_min_avg,  r$rmse_min_sd,
                r$rmse_max_avg,  r$rmse_max_sd))
  }
  cat(sprintf("  %-8s | %20s | %20s | %20s\n",
              "Model", "Daily Mean ME", "Daily Min ME", "Daily Max ME"))
  for (i in seq_len(nrow(ds))) {
    r <- ds[i, ]
    cat(sprintf("  %-8s | %8.2f ± %-8.2f | %8.2f ± %-8.2f | %8.2f ± %-8.2f\n",
                r$model,
                r$me_mean_avg, r$me_mean_sd,
                r$me_min_avg,  r$me_min_sd,
                r$me_max_avg,  r$me_max_sd))
  }
}

# arrange_with_legend ------------------------------------------------------------
# Combine a list of ggplot panels into a grid with a single common legend.
# Avoids ggpubr multi-page list returns and works seamlessly with ggsave().
arrange_with_legend <- function(panels, ncol = 2, nrow = NULL, legend_pos = "bottom") {
  panels <- unname(panels)
  first_p <- NULL
  for (p in panels) {
    if (!is.null(p)) { first_p <- p; break }
  }
  leg <- ggpubr::get_legend(first_p)
  p_grid <- ggpubr::ggarrange(plotlist = panels, ncol = ncol, nrow = nrow, legend = "none")
  if (legend_pos == "top") {
    ggpubr::ggarrange(leg, p_grid, ncol = 1, heights = c(0.08, 1))
  } else {
    ggpubr::ggarrange(p_grid, leg, ncol = 1, heights = c(1, 0.08))
  }
}

# get_example_data -------------------------------------------------------------
# Get path to an example dataset, downloading on demand from anonymous repository
# if not already present locally.
get_example_data <- function(filename,
                             dest_dir = NULL,
                             base_url = "https://anonymous.4open.science/r/microcl_ml_corr-3E14/inst/extdata/",
                             force = FALSE) {
  # 1. Check if the file is bundled inside inst/extdata in installed package
  pkg_file <- system.file("extdata", filename, package = "microclCorr")
  if (!force && nzchar(pkg_file) && file.exists(pkg_file)) {
    return(normalizePath(pkg_file))
  }

  # Check local development paths relative to current working directory
  candidates <- c(
    file.path("inst", "extdata", filename),
    file.path("..", "extdata", filename),
    file.path("..", "inst", "extdata", filename),
    file.path("..", "..", "inst", "extdata", filename),
    file.path("..", "..", "extdata", filename),
    file.path("..", "..", "..", "inst", "extdata", filename),
    file.path("..", "..", "..", "extdata", filename),
    file.path("extdata", filename)
  )
  for (cand in candidates) {
    if (!force && file.exists(cand)) {
      return(normalizePath(cand))
    }
  }

  # 2. Determine cache destination directory
  if (is.null(dest_dir)) {
    dest_dir <- tryCatch(
      tools::R_user_dir("microclCorr", "data"),
      error = function(e) file.path(tempdir(), "microclCorr_data")
    )
  }

  target_file <- file.path(dest_dir, filename)
  if (!force && file.exists(target_file) && file.size(target_file) > 0) {
    return(normalizePath(target_file))
  }

  # 3. Download on demand from anonymous repository
  if (!dir.exists(dest_dir)) {
    dir.create(dest_dir, recursive = TRUE, showWarnings = FALSE)
  }

  clean_base <- sub("/+$", "", base_url)
  download_url <- paste0(clean_base, "/", filename)

  message("Downloading example dataset '", filename, "' from repository...")

  tmp_dest <- tempfile(pattern = "microcl_dl_")
  err <- tryCatch({
    utils::download.file(
      url      = download_url,
      destfile = tmp_dest,
      mode     = "wb",
      quiet    = FALSE
    )
    NULL
  }, error = function(e) e)

  if (!is.null(err) || !file.exists(tmp_dest) || file.size(tmp_dest) == 0) {
    if (file.exists(tmp_dest)) unlink(tmp_dest)
    stop("Failed to download '", filename, "' from: ", download_url,
         if (!is.null(err)) paste0("\nError: ", err$message) else "")
  }

  file.copy(tmp_dest, target_file, overwrite = TRUE)
  unlink(tmp_dest)

  message("Dataset cached at: ", normalizePath(target_file))
  normalizePath(target_file)
}
