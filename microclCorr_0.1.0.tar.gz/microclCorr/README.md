# microclCorr: Correcting Timeseries Microclimate Model Predictions with Machine Learning

[![R-CMD-check](https://img.shields.io/badge/R--CMD--check-passing-brightgreen.svg)](#)
[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)

`microclCorr` is an R package that improves the accuracy of microclimate temperature predictions produced by physical models (such as **NicheMapR**).

Physical models are fundamental tools for understanding how species interact with their thermal environment. By simulating temperatures from first principles — solar radiation, wind, terrain geometry, and heat transfer — they provide mechanistic insight that purely statistical approaches cannot. However, in microhabitats with complex heat-balance conditions not yet fully captured by current physical models, or poor parameterizations due to low-resolution input data, a residual gap remains between model predictions and field measurements.

`microclCorr` bridges that gap using machine learning. Rather than modifying or replacing the physical model, it learns to predict and correct the residual error from a small set of temperature logger measurements. This eliminates the need to manually re-parameterise the physical model for each specific microhabitat. The package includes case studies where ML reduced prediction errors by **58% to 90%** across Mediterranean, coastal, and desert environments.

---

## How it works

A physical model predicts a temperature. A field logger measures the actual temperature. The difference between the two is called the **residual**:

```
residual = measured temperature − physical model prediction
```

`microclCorr` trains a model to predict that residual. The corrected temperature is then:

```
corrected temperature = physical model prediction + predicted residual
```

Two model types are available and compared:

- **Random Forest** — an ensemble of decision trees. Fast, robust, and works well even with small datasets.
- **LSTM** — a neural network designed for time-series data. Uses the past 2 hours of measurements to predict the current residual.

---

## Workflow

Once the aligned CSV is prepared, the ML pipeline proceeds through the following stages:

```mermaid
flowchart TD
    %% Data Preparation
    subgraph Prep [Data preparation]
        L[load_prepared_csv_data] --> C[add_cyclical_time]
        C --> F[get_feature_columns]
        F --> S[split_train_val_test]
    end

    %% Random Forest Training
    subgraph RF [Random Forest Training]
        RF_T[train_rf]
    end

    %% LSTM Training
    subgraph LSTM [LSTM Training]
        SCL[lstm_scaling] --> WIN[lstm_specific_preprocessing]
        WIN --> LTT[train_lstm]
    end

    S --> RF_T
    S --> SCL

    %% Model Selection
    subgraph Sel [Model selection]
        RF_T --> ALGN[align_test_sets]
        LTT --> ALGN
        ALGN --> EVAL[evaluate_correction]
        EVAL --> CMP[Compare models]
        CMP --> SAV[save_correction_model]
    end

    %% Apply to New Data
    subgraph Inf [Apply to New Data]
        LDM[load_correction_model] --> PRD[correct_predictions]
    end
    
    SAV -.-> LDM
```

**Pipeline Stages:**
1. **Data preparation**: Load the aligned CSV, encode cyclical time features, identify predictor columns, and partition the data into training, validation, and test subsets.
2. **Training**: The data is passed to two parallel training branches:
   - **Random Forest**: Fits a Random Forest model.
   - **LSTM**: Normalizes inputs, reformats time series into overlapping windows, and fits the neural network.
3. **Model selection**: Test sets are aligned and evaluated. The model with the best correction accuracy is selected and saved.
4. **Apply to New Data**: The saved model bundle is loaded and applied to correct new physical model predictions.

**What you need to provide:**
- A **logger data CSV** — measured temperatures, timestamps, microhabitat label, and environmental variables
- A **physical model predictions CSV** — model-predicted temperatures for the same location and time period

**Your only pre-processing step** (done outside the package):
1. Join both files by timestamp and add a `residual` column (measured − predicted)
2. *(If using multiple loggers)* Add a microhabitat column if not already present, add a site ID column (e.g. `Site_ID` with values like `"Mishmar River"`), then stack all logger tables into one file

See the [preprocessing examples](inst/examples/preprocessing_examples/) for ready-to-run scripts that demonstrate this step on real data.

---

## Package Verification (`R CMD check`)

For reviewers performing package verification:

```bash
# Install all required and suggested dependencies
Rscript -e 'install.packages(c("knitr", "testthat", "ranger", "keras3", "tensorflow", "reticulate", "rmarkdown"), repos = "https://cloud.r-project.org")'

# Download the microclCorr_0.1.0.tar.gz file from the repository

# Run R CMD check on the built tarball (--no-manual skips PDF manual generation if LaTeX/pdflatex is not installed)
R CMD check --no-manual microclCorr_0.1.0.tar.gz
```

---

## Installation

### 1. Download and install locally

#### Option A: Install from the pre-built tarball (`microclCorr_0.1.0.tar.gz`)

Download `microclCorr_0.1.0.tar.gz` from the repository and install it directly:

```R
# In R:
install.packages("microclCorr_0.1.0.tar.gz", repos = NULL, type = "source")

# Or using remotes:
if (!requireNamespace("remotes", quietly = TRUE)) install.packages("remotes")
remotes::install_local("microclCorr_0.1.0.tar.gz")
```

Alternatively, from the terminal:
```bash
R CMD INSTALL microclCorr_0.1.0.tar.gz
```

#### Option B: Download the full repository (to access examples and raw datasets)

The pre-built `.tar.gz` package contains all package functions and compiled vignettes. If you also want to inspect or reproduce the empirical scenario scripts (`inst/examples/`) and accompanying datasets (`inst/extdata/`), download the full repository as a ZIP archive from:

> **[https://anonymous.4open.science/r/microcl_ml_corr-3E14/](https://anonymous.4open.science/r/microcl_ml_corr-3E14/)**

You can install the package directly from the downloaded ZIP file:

```R
if (!requireNamespace("remotes", quietly = TRUE)) install.packages("remotes")
remotes::install_local("microcl_ml_corr-3E14.zip")
```


### 2. Install core dependencies

```R
install.packages(c("ranger", "reticulate"))
```

### 3. Set up TensorFlow (required for LSTM models only)

The LSTM model uses Python's TensorFlow library under the hood. To set it up:

```R
library(keras3)
install_keras()   # automatically installs TensorFlow in a virtual environment
```

If you already have a conda environment with TensorFlow installed, point R to it:

```R
library(reticulate)
use_condaenv("your_env_name", required = TRUE)
```

---

## Examples

The package includes eight fully worked scenario scripts in [`inst/examples/`](inst/examples/). These correspond directly to the **4 Examples** presented in the accompanying manuscript (in preparation), alongside supplementary scenarios:

| Scenario / Script | Paper Example | Question answered |
|----------|---------------|-----------------|
| [Preprocessing](inst/examples/preprocessing_examples/) | — | How do I prepare my CSV files before running the pipeline? |
| [1 — Valley](inst/examples/scenario_1_valley_single_logger/) | **Example 1** | How well does local correction work? How much logger data do I need? |
| [2 — Beach](inst/examples/scenario_2_beach_single_logger/) | **Example 1** | Same as above for a coastal site, where NicheMapR errors are larger. |
| [3 — Desert](inst/examples/scenario_3_desert_single_logger/) | **Example 1** | Same as above for a desert site, where even 1–2 days of data is enough. |
| [4 — Beach Pooled](inst/examples/scenario_4_beach_pooled/) | **Example 2** | Does training on ALL loggers at once improve accuracy? |
| [5 — Beach Specialized](inst/examples/scenario_5_beach_specialized/) | — | Does training one model per location beat a single pooled model? |
| [6 — Desert Pooled](inst/examples/scenario_6_desert_pooled/) | — | Same as Scenario 4, but across 48 desert loggers. |
| [7 — Desert Specialized](inst/examples/scenario_7_desert_specialized/) | **Example 3** | Same as Scenario 5, but per desert region. |
| [8 — Zero-Shot Transfer](inst/examples/scenario_8_zero_shot_transfer/) | **Example 4** | Can the package correct a site where no logger data exists at all? |

Each example is a self-contained R script with plain-English comments throughout. To run an example, open the corresponding `run_scenario_N.R` file in RStudio and click **Source**.

See the [examples README](inst/examples/README.md) for a summary of results across all scenarios.

---

## License

This package is licensed under the MIT License. See the [`LICENSE`](LICENSE) file for details.
